﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ServiceModel;
using System.Diagnostics; //for debug
using System.ComponentModel; //for bindinglist, inotify
using System.Timers; //Timer

// Location of the proxy.
using CallOut_ConsoleWPF.ServiceReference1;
using System.Collections.ObjectModel;

namespace CallOut_ConsoleWPF
{
    // Specify for the callback to NOT use the current synchronization context
    [CallbackBehavior(
        ConcurrencyMode = ConcurrencyMode.Single,
        UseSynchronizationContext = false)]
    public partial class MainWindow : Window, ServiceReference1.CallOut_CodingServiceCallback
    {

        //Declaration
        private SynchronizationContext _uiSyncContext = null;
        private ServiceReference1.CallOut_CodingServiceClient _CallOut_CodingService = null;

        //For toggle of button
        private bool _isConnected = false;

        //For binding of list to datagirdview
        private BindingList<ConsoleLog> _ConsoleLogList = new BindingList<ConsoleLog>();
        private BindingList<UnitsStatus> _UnitsStatusList = new BindingList<UnitsStatus>();

        //Holding current codingID (May had potential issue of overwrite need to change later)
        private string _currCodingID = "";

        public MainWindow()
        {
            InitializeComponent();
            //Sub window load and closing eventhandler
            Loaded += MyWindow_Loaded;
            Closing += MyWindow_Closing;
        }

        private void MyWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Capture the UI synchronization context
            _uiSyncContext = SynchronizationContext.Current;

            // The client callback interface must be hosted for the server to invoke the callback
            // Open a connection to the message service via the proxy (qualifier ServiceReference1 needed due to name clash)
            _CallOut_CodingService = new ServiceReference1.CallOut_CodingServiceClient(new InstanceContext(this), "WSDualHttpBinding_CallOut_CodingService");
            _CallOut_CodingService.Open();

            //DataGrid Bind
            _UnitsStatusList.Clear();
            this.dgUnits.ItemsSource = _UnitsStatusList;

            // Load combobox
            foreach (StationStatus station in _CallOut_CodingService.GetStationStatus())
            {
                this.cbID.Items.Add(station.Station);
            }

            //hide accept and reject button
            this.btnAck.Visibility = Visibility.Collapsed;
            this.btnReject.Visibility = Visibility.Collapsed;

        }

        private void MyWindow_Closing(object sender, CancelEventArgs e)
        {
            //Terminate the connection to the service.
            if (_isConnected)
            {
                _CallOut_CodingService.Close();
            }

        }

        private void btnSettings_Click(object sender, RoutedEventArgs e)
        {
            wndSettings setting = new wndSettings();
            setting.ShowDialog();
        }

        private void btnConnect_Click(object sender, RoutedEventArgs e)
        {
            if (_isConnected)
            {
                // Let the service know that this user is leaving
                _CallOut_CodingService.ConsoleLeave(this.cbID.Text);

                //Change title of application
                this.Title = "Call Out Console";

                //Toggle button display
                _isConnected = false;
                this.txtConnect.Text = "Connect";
                this.cbID.IsEnabled = true;
            }
            else
            {
                //contact the service.
                _CallOut_CodingService.ConsoleJoin(this.cbID.Text);

                //Change title of application
                this.Title = "Call Out Console [" + this.cbID.Text + "]";

                //Toggle button display
                _isConnected = true;
                this.txtConnect.Text = "Disconnect";
                this.cbID.IsEnabled = false;
            }
        }

        private void btnAck_Click(object sender, RoutedEventArgs e)
        {
            //Send Coding ack message back to gateway
            SendAckCodingIncidentMsg("Acknowledged");

            //disable ack and reject button
            this.btnAck.Visibility = Visibility.Collapsed;
            this.btnReject.Visibility = Visibility.Collapsed;

            this.lblTestStatus.Text = "Acknowledged";
        }

        private void btnReject_Click(object sender, RoutedEventArgs e)
        {
            //Send Coding ack message back to gateway
            SendAckCodingIncidentMsg("Rejected");

            //disable ack and reject button
            this.btnAck.Visibility = Visibility.Collapsed;
            this.btnReject.Visibility = Visibility.Collapsed;

            this.lblTestStatus.Text = "Rejected";
        }

        private void SendAckCodingIncidentMsg(string status)
        {
            CodingAckMessage codingackmsg = new CodingAckMessage();
            codingackmsg.ConsoleID = this.cbID.Text;
            codingackmsg.CodingID = _currCodingID;
            codingackmsg.AckStatus = status;
            DateTime currentdt = DateTime.Now;
            codingackmsg.AckTimeStamp = String.Format("{0:g}", currentdt);
            List<string> dispatchUnits = new List<string>();
            foreach (UnitsStatus unitstatus in _UnitsStatusList)
            {
                dispatchUnits.Add(unitstatus.CallSign);
            }
            codingackmsg.AckUnits = dispatchUnits.ToArray();
            _CallOut_CodingService.AckCodingIncidentMsg(codingackmsg);
        }

        private void UpdateDetails(CodingIncidentMessage codingIncidentMsg)
        {
            //Update the Display panel details
            this.txtIncidentSummary.Text = codingIncidentMsg.IncidentNo+": "+codingIncidentMsg.IncidentType;
            this.txtLocationSummary.Text = codingIncidentMsg.IncidentType + " at " + codingIncidentMsg.IncidentLocation.Street;
            string prioralarm = "PRIORITY: " + codingIncidentMsg.IncidentPriority.ToString()+
                "  - ALARM: " + codingIncidentMsg.IncidentAlarm.ToString()+
                "  -  DISPATCHED: " + String.Format("{0:g}", codingIncidentMsg.DispatchDateTime);
            this.txtPriorAlarm.Text = prioralarm;

            this.txtLocationName.Text = codingIncidentMsg.IncidentLocation.Name;
            this.txtLocationStreet.Text = codingIncidentMsg.IncidentLocation.Street;
            this.txtLocationUnit.Text = codingIncidentMsg.IncidentLocation.Unit;
            this.txtLocationStateCity.Text = "City: "+codingIncidentMsg.IncidentLocation.City+
                " - State: " + codingIncidentMsg.IncidentLocation.State;
            this.txtLocationPostal.Text = "Singapore " + codingIncidentMsg.IncidentLocation.PostalCode;             

            this.lblTestStatus.Text = "";

            //Clear and add new unit into the list
            _UnitsStatusList.Clear();

            foreach (CodingUnits unit in codingIncidentMsg.DispatchUnits)
            {
                if (unit.UnitCurrentStation.Equals(this.cbID.Text))
                {
                    UnitsStatus unitstatus = new UnitsStatus();
                    unitstatus.CallSign = unit.Callsign;
                    unitstatus.UnitType = unit.UnitType;
                    _UnitsStatusList.Add(unitstatus);
                }

                //For test message data
                if (unit.UnitCurrentStation.Equals(""))
                {
                    UnitsStatus unitstatus = new UnitsStatus();
                    unitstatus.CallSign = unit.Callsign;
                    unitstatus.UnitType = unit.UnitType;
                    _UnitsStatusList.Add(unitstatus);
                }
            }

            //Update current codingID
            _currCodingID = codingIncidentMsg.CodingID;

            //Start timer for 10 sec to auto reject
            System.Timers.Timer AutoRejectTimer = new System.Timers.Timer();
            AutoRejectTimer.Interval = 10000; //10 sec
            AutoRejectTimer.Elapsed += delegate { Timeout(codingIncidentMsg.IncidentNo); };
            AutoRejectTimer.AutoReset = false;
            AutoRejectTimer.Start();

        }

        public void Timeout(string incidentNo)
        {
            Debug.WriteLine("Timeout");
            SendOrPostCallback callback =
                    delegate(object state)
                    {
                        //Already ack or reject 10 sec do nth
                        if (this.lblTestStatus.Text.Equals(""))
                        {
                            //Create a console log entry
                            //CreateConsoleLogEntry("Rejected");

                            //Send Coding ack message back to gateway
                            SendAckCodingIncidentMsg("Rejected");

                            //disable ack and reject button
                            this.btnAck.Visibility = Visibility.Collapsed;
                            this.btnReject.Visibility = Visibility.Collapsed;

                            this.lblTestStatus.Text = "Rejected";

                        }
                    };

            _uiSyncContext.Post(callback, "Message Timeout");

        }

        #region CallOut_CodingServiceCallback Methods

        public void ConsoleDisplayMsg(CodingIncidentMessage codingIncidentMsg)
        {
            SendOrPostCallback callback =
            delegate(object state)
            {
                this.UpdateDetails(codingIncidentMsg);
                this.btnAck.Visibility = Visibility.Visible;
                this.btnReject.Visibility = Visibility.Visible;
            };

            _uiSyncContext.Post(callback, "updatedetails");
        }

        public void ConsoleRcvConnStatus()
        {
            SendOrPostCallback callback =
                delegate(object state)
                {
                    _CallOut_CodingService.ReplyConnStatus(this.cbID.Text);
                };

            _uiSyncContext.Post(callback, "rcv conn status request");
        }

        #region Methods not for Console

        public void EditConnStatus(string Name, string Status)
        { }
        public void RcvCodingAckMsg(CodingAckMessage codingAckMsg)
        { }
        public void NotifyConsoleNotConnected(string userName, CodingIncidentMessage codingIncidentMsg)
        { }
        public void GatewayRcvConnStatus(string station)
        { }

        #endregion

        #endregion

    }

    public class ConsoleLog : INotifyPropertyChanged
    {
        private string _codingID;
        private string _acktimestamp;
        private string _ackfrom;
        private string _ackstatus;
        public event PropertyChangedEventHandler PropertyChanged;

        public string CodingID
        {
            get { return _codingID; }
            set
            {
                _codingID = value;
                this.NotifyPropertyChanged("CodingID");
            }
        }
        public string AckTimeStamp
        {
            get { return _acktimestamp; }
            set
            {
                _acktimestamp = value;
                this.NotifyPropertyChanged("AckTimeStamp");
            }
        }
        public string AckFrom
        {
            get { return _ackfrom; }
            set
            {
                _ackfrom = value;
                this.NotifyPropertyChanged("AckFrom");
            }
        }
        public string AckStatus
        {
            get { return _ackstatus; }
            set
            {
                _ackstatus = value;
                this.NotifyPropertyChanged("AckStatus");
            }
        }

        private void NotifyPropertyChanged(string name)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(name));
        }
    }

    public class UnitsStatus : INotifyPropertyChanged
    {
        private string _callsign;
        private string _unittype;
        public event PropertyChangedEventHandler PropertyChanged;

        public string CallSign
        {
            get { return _callsign; }
            set
            {
                _callsign = value;
                this.NotifyPropertyChanged("CallSign");
            }
        }
        public string UnitType
        {
            get { return _unittype; }
            set
            {
                _unittype = value;
                this.NotifyPropertyChanged("UnitType");
            }
        }

        private void NotifyPropertyChanged(string name)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(name));
        }
    }

}
